<div class="elgg-dropzone-preview">
	<div class="elgg-dropzone-col-1of12 elgg-dropzone-thumbnail">
		<img data-dz-thumbnail />
	</div>
	<div class="elgg-dropzone-col-8of12 elgg-dropzone-filename">
		<span class="elgg-dropzone-success-icon"></span>
		<span class="elgg-dropzone-error-icon"></span>
		<span data-dz-name></span>
	</div>
	<div class="elgg-dropzone-col-2of12 elgg-dropzone-size" data-dz-size></div>
	<div class="elgg-dropzone-col-1of12">
		<a class="elgg-dropzone-remove-icon" title="<?php echo elgg_echo('dropzone:remove_file') ?>" data-dz-remove></a>
	</div>
	<div class="elgg-dropzone-messages">
		<div data-dz-successmessage></div>
		<div data-dz-errormessage></div>
	</div>
	<div class="elgg-dropzone-progress"><div class="elgg-dropzone-upload" data-dz-uploadprogress></div></div>
</div>