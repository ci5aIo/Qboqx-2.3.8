relative_assets = true

css_dir = "views/default/"
sass_dir = "sass"

output_style = :compact
line_comments = false
preferred_syntax = :scss
