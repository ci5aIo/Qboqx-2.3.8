<?php

update_subtype('object', 'widget', 'ElggWidget');
