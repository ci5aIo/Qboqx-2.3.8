<?php

echo elgg_view('input/hidden', ['name' => 'q']);
