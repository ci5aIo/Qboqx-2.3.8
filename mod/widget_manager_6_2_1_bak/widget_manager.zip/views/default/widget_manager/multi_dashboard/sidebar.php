<?php

elgg_load_js("lightbox");
elgg_load_css("lightbox");

elgg_require_js('widget_manager/multi_dashboard');
