<?php
return [
    // viewtype
    'default' => [
       'js/widget_manager/widgets/image_slider/flexslider.js' => __DIR__ . '/vendors/flexslider/jquery.flexslider-min.js',
       'js/widget_manager/widgets/image_slider/s3Slider.js' => __DIR__ . '/vendors/s3slider/s3Slider.js',
    ],
];